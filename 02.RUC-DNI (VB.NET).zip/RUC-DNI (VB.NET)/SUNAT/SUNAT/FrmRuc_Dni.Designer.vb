﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SunatOnline
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtCapcha = New System.Windows.Forms.TextBox()
        Me.txtNumDni = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.txtRuc = New System.Windows.Forms.TextBox()
        Me.txtDireccion = New System.Windows.Forms.TextBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.btnActualizar = New System.Windows.Forms.Button()
        Me.btnConsultar = New System.Windows.Forms.Button()
        Me.pictureCapcha = New System.Windows.Forms.PictureBox()
        Me.txtTelefono = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtTipoEmpresa = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtRazon = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.btnActualiza = New System.Windows.Forms.Button()
        Me.BtnReniec = New System.Windows.Forms.Button()
        Me.BtnActReniec = New System.Windows.Forms.Button()
        Me.pictureCapchaE = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txttipo_dcto = New System.Windows.Forms.ComboBox()
        CType(Me.pictureCapcha, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureCapchaE, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtCapcha
        '
        Me.txtCapcha.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCapcha.Location = New System.Drawing.Point(351, 43)
        Me.txtCapcha.Margin = New System.Windows.Forms.Padding(4)
        Me.txtCapcha.MaxLength = 4
        Me.txtCapcha.Name = "txtCapcha"
        Me.txtCapcha.Size = New System.Drawing.Size(102, 25)
        Me.txtCapcha.TabIndex = 34
        '
        'txtNumDni
        '
        Me.txtNumDni.Location = New System.Drawing.Point(191, 40)
        Me.txtNumDni.Margin = New System.Windows.Forms.Padding(4)
        Me.txtNumDni.MaxLength = 11
        Me.txtNumDni.Name = "txtNumDni"
        Me.txtNumDni.Size = New System.Drawing.Size(93, 25)
        Me.txtNumDni.TabIndex = 2
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.BackColor = System.Drawing.Color.White
        Me.label3.Location = New System.Drawing.Point(293, 43)
        Me.label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(50, 18)
        Me.label3.TabIndex = 32
        Me.label3.Text = "Imagen"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.BackColor = System.Drawing.Color.White
        Me.label2.Location = New System.Drawing.Point(155, 43)
        Me.label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(35, 18)
        Me.label2.TabIndex = 33
        Me.label2.Text = "RUC"
        '
        'txtRuc
        '
        Me.txtRuc.BackColor = System.Drawing.Color.White
        Me.txtRuc.Location = New System.Drawing.Point(146, 107)
        Me.txtRuc.Margin = New System.Windows.Forms.Padding(4)
        Me.txtRuc.Name = "txtRuc"
        Me.txtRuc.Size = New System.Drawing.Size(191, 25)
        Me.txtRuc.TabIndex = 30
        '
        'txtDireccion
        '
        Me.txtDireccion.BackColor = System.Drawing.Color.White
        Me.txtDireccion.Location = New System.Drawing.Point(145, 202)
        Me.txtDireccion.Margin = New System.Windows.Forms.Padding(4)
        Me.txtDireccion.Name = "txtDireccion"
        Me.txtDireccion.Size = New System.Drawing.Size(663, 25)
        Me.txtDireccion.TabIndex = 31
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Location = New System.Drawing.Point(33, 110)
        Me.label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(110, 18)
        Me.label4.TabIndex = 27
        Me.label4.Text = "Número de RUC: "
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(31, 205)
        Me.label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(112, 18)
        Me.label1.TabIndex = 28
        Me.label1.Text = "Domicilio Fiscal : "
        '
        'btnActualizar
        '
        Me.btnActualizar.Location = New System.Drawing.Point(1005, 71)
        Me.btnActualizar.Margin = New System.Windows.Forms.Padding(4)
        Me.btnActualizar.Name = "btnActualizar"
        Me.btnActualizar.Size = New System.Drawing.Size(50, 46)
        Me.btnActualizar.TabIndex = 24
        Me.btnActualizar.Text = "Actualizar Captcha"
        Me.btnActualizar.UseVisualStyleBackColor = True
        '
        'btnConsultar
        '
        Me.btnConsultar.Location = New System.Drawing.Point(455, 32)
        Me.btnConsultar.Margin = New System.Windows.Forms.Padding(4)
        Me.btnConsultar.Name = "btnConsultar"
        Me.btnConsultar.Size = New System.Drawing.Size(129, 46)
        Me.btnConsultar.TabIndex = 25
        Me.btnConsultar.Text = "Consulta sUNAT"
        Me.btnConsultar.UseVisualStyleBackColor = True
        '
        'pictureCapcha
        '
        Me.pictureCapcha.BackColor = System.Drawing.Color.WhiteSmoke
        Me.pictureCapcha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pictureCapcha.Location = New System.Drawing.Point(604, 24)
        Me.pictureCapcha.Margin = New System.Windows.Forms.Padding(4)
        Me.pictureCapcha.Name = "pictureCapcha"
        Me.pictureCapcha.Size = New System.Drawing.Size(179, 64)
        Me.pictureCapcha.TabIndex = 23
        Me.pictureCapcha.TabStop = False
        '
        'txtTelefono
        '
        Me.txtTelefono.BackColor = System.Drawing.Color.White
        Me.txtTelefono.Location = New System.Drawing.Point(145, 251)
        Me.txtTelefono.Margin = New System.Windows.Forms.Padding(4)
        Me.txtTelefono.Name = "txtTelefono"
        Me.txtTelefono.ReadOnly = True
        Me.txtTelefono.Size = New System.Drawing.Size(663, 25)
        Me.txtTelefono.TabIndex = 527
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(71, 255)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(69, 18)
        Me.Label12.TabIndex = 519
        Me.Label12.Text = "Teléfonos:"
        '
        'txtTipoEmpresa
        '
        Me.txtTipoEmpresa.BackColor = System.Drawing.Color.White
        Me.txtTipoEmpresa.Location = New System.Drawing.Point(146, 169)
        Me.txtTipoEmpresa.Margin = New System.Windows.Forms.Padding(4)
        Me.txtTipoEmpresa.Name = "txtTipoEmpresa"
        Me.txtTipoEmpresa.ReadOnly = True
        Me.txtTipoEmpresa.Size = New System.Drawing.Size(662, 25)
        Me.txtTipoEmpresa.TabIndex = 521
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(51, 172)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(93, 18)
        Me.Label16.TabIndex = 512
        Me.Label16.Text = "Tipo Empresa:"
        '
        'txtRazon
        '
        Me.txtRazon.BackColor = System.Drawing.Color.White
        Me.txtRazon.Location = New System.Drawing.Point(146, 138)
        Me.txtRazon.Margin = New System.Windows.Forms.Padding(4)
        Me.txtRazon.Name = "txtRazon"
        Me.txtRazon.ReadOnly = True
        Me.txtRazon.Size = New System.Drawing.Size(504, 25)
        Me.txtRazon.TabIndex = 520
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(53, 141)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(89, 18)
        Me.Label17.TabIndex = 511
        Me.Label17.Text = "Razón Social:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(188, 69)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 18)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "Telefonos"
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(821, 362)
        Me.ShapeContainer1.TabIndex = 528
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BackColor = System.Drawing.Color.White
        Me.RectangleShape1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape1.CornerRadius = 6
        Me.RectangleShape1.Location = New System.Drawing.Point(11, 21)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(797, 68)
        '
        'btnActualiza
        '
        Me.btnActualiza.Location = New System.Drawing.Point(146, 293)
        Me.btnActualiza.Margin = New System.Windows.Forms.Padding(4)
        Me.btnActualiza.Name = "btnActualiza"
        Me.btnActualiza.Size = New System.Drawing.Size(179, 46)
        Me.btnActualiza.TabIndex = 529
        Me.btnActualiza.Text = "Actualizar Captcha Sunat"
        Me.btnActualiza.UseVisualStyleBackColor = True
        '
        'BtnReniec
        '
        Me.BtnReniec.Location = New System.Drawing.Point(391, 293)
        Me.BtnReniec.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnReniec.Name = "BtnReniec"
        Me.BtnReniec.Size = New System.Drawing.Size(179, 46)
        Me.BtnReniec.TabIndex = 530
        Me.BtnReniec.Text = "Consulta Reniec"
        Me.BtnReniec.UseVisualStyleBackColor = True
        '
        'BtnActReniec
        '
        Me.BtnActReniec.Location = New System.Drawing.Point(610, 293)
        Me.BtnActReniec.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnActReniec.Name = "BtnActReniec"
        Me.BtnActReniec.Size = New System.Drawing.Size(179, 46)
        Me.BtnActReniec.TabIndex = 531
        Me.BtnActReniec.Text = "Actualizar Captcha Reniec"
        Me.BtnActReniec.UseVisualStyleBackColor = True
        '
        'pictureCapchaE
        '
        Me.pictureCapchaE.BackColor = System.Drawing.Color.WhiteSmoke
        Me.pictureCapchaE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pictureCapchaE.Location = New System.Drawing.Point(629, 99)
        Me.pictureCapchaE.Margin = New System.Windows.Forms.Padding(4)
        Me.pictureCapchaE.Name = "pictureCapchaE"
        Me.pictureCapchaE.Size = New System.Drawing.Size(179, 45)
        Me.pictureCapchaE.TabIndex = 533
        Me.pictureCapchaE.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(19, 24)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(121, 18)
        Me.Label5.TabIndex = 535
        Me.Label5.Text = "Tipo de Documento"
        '
        'txttipo_dcto
        '
        Me.txttipo_dcto.FormattingEnabled = True
        Me.txttipo_dcto.Items.AddRange(New Object() {"DNI", "RUC"})
        Me.txttipo_dcto.Location = New System.Drawing.Point(23, 43)
        Me.txttipo_dcto.Name = "txttipo_dcto"
        Me.txttipo_dcto.Size = New System.Drawing.Size(121, 26)
        Me.txttipo_dcto.TabIndex = 536
        '
        'SunatOnline
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(832, 362)
        Me.Controls.Add(Me.txttipo_dcto)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.pictureCapchaE)
        Me.Controls.Add(Me.BtnActReniec)
        Me.Controls.Add(Me.BtnReniec)
        Me.Controls.Add(Me.btnActualiza)
        Me.Controls.Add(Me.txtTelefono)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtTipoEmpresa)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txtRazon)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txtCapcha)
        Me.Controls.Add(Me.txtNumDni)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.txtRuc)
        Me.Controls.Add(Me.txtDireccion)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnActualizar)
        Me.Controls.Add(Me.btnConsultar)
        Me.Controls.Add(Me.pictureCapcha)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "SunatOnline"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Sunat en Linea"
        CType(Me.pictureCapcha, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureCapchaE, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents txtCapcha As System.Windows.Forms.TextBox
    Private WithEvents txtNumDni As System.Windows.Forms.TextBox
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents txtRuc As System.Windows.Forms.TextBox
    Private WithEvents txtDireccion As System.Windows.Forms.TextBox
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents btnActualizar As System.Windows.Forms.Button
    Private WithEvents btnConsultar As System.Windows.Forms.Button
    Private WithEvents pictureCapcha As System.Windows.Forms.PictureBox
    Friend WithEvents txtTelefono As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtTipoEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtRazon As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents btnActualiza As System.Windows.Forms.Button
    Private WithEvents BtnReniec As System.Windows.Forms.Button
    Private WithEvents BtnActReniec As System.Windows.Forms.Button
    Private WithEvents pictureCapchaE As System.Windows.Forms.PictureBox
    Private WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txttipo_dcto As System.Windows.Forms.ComboBox
    Private WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Private WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape

End Class
