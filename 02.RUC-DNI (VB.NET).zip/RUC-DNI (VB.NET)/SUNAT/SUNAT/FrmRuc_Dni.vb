﻿Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.IO
Imports System.Linq
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Windows.Forms
Imports Tesseract
Imports AForge
Imports AForge.Imaging
Imports AForge.Imaging.Filters
Imports AForge.Imaging.Textures
Public Class SunatOnline
    Dim myInfo As Sunat_Ruc
    Dim MyInfoReniec As Reniec

    '********************CAMBIO EL 12-02-2017  ************************************
    Dim red As New IntRange(0, 255)
    Dim green As New IntRange(0, 255)
    Dim blue As New IntRange(0, 255)
    Dim Texto As String = String.Empty
    '******************************************************************************

    'Public Sub New()
    '    InitializeComponent()
    '    Try
    '        'Call CargarImagen()
    '        'Call LeerCaptchaSunat() ' ACA CARGA EL CAPTCHA EN EL TEXTBOX
    '        CargarImagenReniec()
    '        LeerCaptchaReniec()
    '    Catch ex As Exception
    '        MessageBox.Show(ex.Message)
    '    End Try
    'End Sub


    Sub CaptionResul()
        Try
            'myInfo.GetInfo(Me.txtRuc.Text, Me.txtCapcha.Text) ' ingresado 30-01-2017
            Select Case myInfo.GetResul
                Case Sunat_Ruc.Resul.Ok
                    Me.txtRuc.Text = txtNumDni.Text
                    Me.txtRazon.Text = myInfo.Nombres
                    Me.txtDireccion.Text = myInfo.Direccion
                    Me.txtTipoEmpresa.Text = myInfo.TipoEmpresa
                    'Me.TxtNomComercial.Text = myInfo.NomComercial
                    'Me.txtEstado.Text = myInfo.Estado
                    'Me.txtCondicionContribuyente.Text = myInfo.CondiContribuyente
                    Me.txtTelefono.Text = myInfo.Telefono
                    'Me.TxtIniActividades.Text = myInfo.InicioActiviades
                    'Me.TxtFInscripcion.Text = myInfo.FInscripcion
                    'Me.TxtEmiComprobante.Text = myInfo.EmiComprobante
                    'Me.TxtSisContabilidad.Text = myInfo.SisContabilidad
                    'Me.TxtComerExterior.Text = myInfo.ComerExterior
                    'Me.TxtOficio.Text = myInfo.Oficio
                    Me.txtNumDni.Clear()
                    Me.txtCapcha.Clear()
                    Exit Select
                Case Sunat_Ruc.Resul.NoResul
                    Me.Label8.Text = "No existe RUC"
                    Me.txtRuc.Clear()
                    Me.txtRazon.Clear()
                    Me.txtTipoEmpresa.Clear()
                    'Me.TxtNomComercial.Clear()
                    'Me.txtCondicionContribuyente.Clear()
                    'Me.TxtIniActividades.Clear()
                    'Me.TxtFInscripcion.Clear()
                    'Me.txtDireccion.Clear()
                    'Me.txtEstado.Clear()
                    Me.txtTelefono.Clear()
                    'Me.TxtEmiComprobante.Clear()
                    'Me.TxtSisContabilidad.Clear()
                    'Me.TxtOficio.Clear()
                    'Me.TxtComerExterior.Clear()

                    Exit Select
                Case Sunat_Ruc.Resul.ErrorCapcha
                    CargarImagen()
                    'LeerCaptchaSunat()
                    Me.Label8.Text = "Ingrese imagen correctamente"
                    Exit Select
                Case Sunat_Ruc.Resul.[Error]
                    Me.Label8.Text = "Error Desconocido"
                    Exit Select
            End Select
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Sub CaptionResul_Reniec()
        Try
            'myInfo.GetInfo(Me.txtRuc.Text, Me.txtCapcha.Text) ' ingresado 30-01-2017
            Select Case MyInfoReniec.GetResul
                Case Reniec.Resul.Ok
                    Me.txtRuc.Text = txtNumDni.Text
                    Me.txtRazon.Text = MyInfoReniec.Nombres
                    'Me.txtDireccion.Text = MyInfoReniec.Direccion
                    ' Me.txtTipoEmpresa.Text = MyInfoReniec.TipoEmpresa
                   
                    'Me.txtTelefono.Text = MyInfoReniec.Telefono
                  
                    Me.txtNumDni.Clear()
                    Me.txtCapcha.Clear()
                    Exit Select
                Case Reniec.Resul.NoResul
                    Me.Label8.Text = "No existe RUC"
                    Me.txtRuc.Clear()
                    Me.txtRazon.Clear()
                    Me.txtTipoEmpresa.Clear()
                  
                    Me.txtTelefono.Clear()
                   
                    Exit Select
                Case Reniec.Resul.ErrorCapcha
                    CargarImagen()
                    'LeerCaptchaSunat()
                    Me.Label8.Text = "Ingrese imagen correctamente"
                    Exit Select
                Case Reniec.Resul.[Error]
                    Me.Label8.Text = "Error Desconocido"
                    Exit Select
            End Select
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Sub CargarImagen()
        Try
            If myInfo Is Nothing Then
                myInfo = New Sunat_Ruc
            End If
            Me.pictureCapcha.Image = myInfo.GetCapcha
            LeerCaptchaSunat()
        Catch ex As Exception
            Throw ex
        End Try

    End Sub


    Private Sub btnConsultar_Click(sender As Object, e As EventArgs) Handles btnConsultar.Click
        Label8.Text = ""
        If Me.txtNumDni.Text.Length = 11 And txttipo_dcto.Text = "RUC" Then

            myInfo.GetInfo(Me.txtNumDni.Text, Me.txtCapcha.Text)
            CaptionResul()
            CargarImagen()

        ElseIf Me.txtNumDni.Text.Length = 8 And txttipo_dcto.Text = "RUC" Then
            Try
                MyInfoReniec.GetInfo(Me.txtNumDni.Text, Me.txtCapcha.Text)
                Select Case MyInfoReniec.GetResul
                    Case Reniec.Resul.Ok
                        limpiarReniec()
                        txtRuc.Text = MyInfoReniec.Dni
                        txtRazon.Text = MyInfoReniec.Nombres + " " + MyInfoReniec.ApePaterno + " " + MyInfoReniec.ApeMaterno
                        '  txtreniec_apellido.Text = MyInfoReniec.ApePaterno + " " + MyInfoReniec.ApeMaterno
                        Exit Select
                    Case Reniec.Resul.NoResul
                        limpiarReniec()
                        MessageBox.Show("No Existe DNI")
                        Exit Select
                    Case Reniec.Resul.ErrorCapcha
                        limpiarReniec()
                        MessageBox.Show("Ingrese imagen correctamente")
                        Exit Select
                    Case Else
                        MessageBox.Show("Error Desconocido")
                        Exit Select
                End Select
                'Comentar esta linea para consultar multiples DNI usando un solo captcha.
                CargarImagenReniec()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If


      
        Try
            If Me.txtNumDni.Text.Length <> 11 Then
                Me.Label8.Text = "Ingrese ruc Valido"
                Me.txtNumDni.SelectAll()
                Me.txtNumDni.Focus()
                Return
            End If
            'myInfo.GetInfo(Me.txtNumDni.Text, Me.txtCapcha.Text)
            'CaptionResul()
            'CargarImagen()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        'llamamos a los metodos de la libreria ConsultaReniec...

    End Sub

    Private Sub SunatOnline_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Label8.Text = ""
        'LeerCaptchaSunat()
    End Sub

    Private Sub LeerCaptchaSunat()
        Using engine = New TesseractEngine("./tessdata", "eng", EngineMode.Default)
            Using image = New System.Drawing.Bitmap(pictureCapcha.Image)
                Using pix = PixConverter.ToPix(image)
                    Using page = engine.Process(pix)
                        Dim Porcentaje = [String].Format("{0:P}", page.GetMeanConfidence())
                        Dim CaptchaTexto As String = page.GetText()
                        Dim eliminarChars As Char() = {ControlChars.Lf, " "c}
                        CaptchaTexto = CaptchaTexto.TrimEnd(eliminarChars)
                        CaptchaTexto = CaptchaTexto.Replace(" ", String.Empty)
                        CaptchaTexto = Regex.Replace(CaptchaTexto, "[^a-zA-Z]+", String.Empty)
                        If CaptchaTexto <> String.Empty And CaptchaTexto.Length = 4 Then
                            txtCapcha.Text = CaptchaTexto.ToUpper()
                        Else
                            CargarImagen()
                        End If
                    End Using
                End Using

            End Using
        End Using

      

    End Sub

    Private Sub btnActualiza_Click(sender As System.Object, e As System.EventArgs) Handles btnActualiza.Click
        Try
            CargarImagen()
            LeerCaptchaSunat()
            Me.txtCapcha.SelectAll()
            Me.txtCapcha.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub txtCapcha_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtCapcha.TextChanged
        'LeerCaptchaSunat()
    End Sub

    Private Sub BtnReniec_Click(sender As System.Object, e As System.EventArgs) Handles BtnReniec.Click
        Try
            If Me.txtNumDni.Text.Length <> 8 Then
                MessageBox.Show("Ingreso Dni Valido")
                txtNumDni.SelectAll()
                txtNumDni.Focus()
                Return
            End If
            MyInfoReniec.GetInfo(Me.txtNumDni.Text, Me.txtCapcha.Text)
            Select Case MyInfoReniec.GetResul
                Case Reniec.Resul.Ok
                    limpiarReniec()
                    txtRuc.Text = MyInfoReniec.Dni
                    txtRazon.Text = MyInfoReniec.Nombres + " " + MyInfoReniec.ApePaterno + " " + MyInfoReniec.ApeMaterno
                    '  txtreniec_apellido.Text = MyInfoReniec.ApePaterno + " " + MyInfoReniec.ApeMaterno
                    Exit Select
                Case Reniec.Resul.NoResul
                    limpiarReniec()
                    MessageBox.Show("No Existe DNI")
                    Exit Select
                Case Reniec.Resul.ErrorCapcha
                    limpiarReniec()
                    MessageBox.Show("Ingrese imagen correctamente")
                    Exit Select
                Case Else
                    MessageBox.Show("Error Desconocido")
                    Exit Select
            End Select
            'Comentar esta linea para consultar multiples DNI usando un solo captcha.
            CargarImagenReniec()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub AplicacionFiltros()
        Dim bmp As New Bitmap(pictureCapcha.Image)
        FiltroInvertir(bmp)
        ColorFiltros()
        Dim bmp1 As New Bitmap(pictureCapchaE.Image)
        FiltroInvertir(bmp1)
        Dim bmp2 As New Bitmap(pictureCapchaE.Image)
        FiltroSharpen(bmp2)
    End Sub
    Private Sub FiltroInvertir(bmp As Bitmap)
        Dim Filtro As IFilter = New Invert()
        Dim XImage As Bitmap = Filtro.Apply(bmp)
        pictureCapchaE.Image = XImage
    End Sub
    Private Sub ColorFiltros()
        '********************CAMBIO EL 12-02-2017  ************************************
        'Red Min - MAX
        red.Min = Math.Min(red.Max, Byte.Parse("229"))
        red.Max = Math.Max(red.Min, Byte.Parse("255"))
        'Verde Min - MAX
        green.Min = Math.Min(green.Max, Byte.Parse("0"))
        green.Max = Math.Max(green.Min, Byte.Parse("255"))
        'Azul Min - MAX
        blue.Min = Math.Min(blue.Max, Byte.Parse("0"))
        blue.Max = Math.Max(blue.Min, Byte.Parse("130"))
        ActualizarFiltro()
    End Sub
    Private Sub ActualizarFiltro()
        '********************CAMBIO EL 12-02-2017  ************************************
        Dim FiltroColor As New ColorFiltering()
        'FiltroColor.Red = New IntRange(100, 255)
        'FiltroColor.Green = New IntRange(0, 75)
        'FiltroColor.Blue = New IntRange(0, 75)
        FiltroColor.Red = red
        FiltroColor.Green = green
        FiltroColor.Blue = blue
        Dim Filtro As IFilter = FiltroColor
        Dim bmp As New Bitmap(pictureCapchaE.Image)
        Dim XImage As Bitmap = Filtro.Apply(bmp)
        pictureCapchaE.Image = XImage
    End Sub
    Private Sub FiltroSharpen(bmp As Bitmap)
        Dim Filtro As IFilter = New Sharpen()
        Dim XImage As Bitmap = Filtro.Apply(bmp)
        pictureCapchaE.Image = XImage
    End Sub

    Private Sub CargarImagenReniec()
        Try
            If MyInfoReniec Is Nothing Then
                MyInfoReniec = New Reniec()
            End If
            Me.pictureCapcha.Image = MyInfoReniec.GetCapcha
            AplicacionFiltros()
            LeerCaptchaReniec()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub LeerCaptchaReniec()
        Using engine = New TesseractEngine("./tessdata", "eng", EngineMode.Default)
            Using image = New System.Drawing.Bitmap(pictureCapchaE.Image)
                Using pix = PixConverter.ToPix(image)
                    Using page = engine.Process(pix)
                        Dim Porcentaje = [String].Format("{0:P}", page.GetMeanConfidence())
                        Dim CaptchaTexto As String = page.GetText()
                        Dim eliminarChars As Char() = {ControlChars.Lf, " "c}
                        CaptchaTexto = CaptchaTexto.TrimEnd(eliminarChars)
                        CaptchaTexto = CaptchaTexto.Replace(" ", String.Empty)
                        CaptchaTexto = Regex.Replace(CaptchaTexto, "[^a-zA-Z]+", String.Empty)
                        If CaptchaTexto <> String.Empty And CaptchaTexto.Length = 4 Then
                            txtCapcha.Text = CaptchaTexto.ToUpper()
                        Else
                            CargarImagenReniec()
                        End If
                    End Using
                End Using
            End Using
        End Using
    End Sub

    Private Sub limpiarReniec()
        txtRuc.Text = String.Empty
        txtRazon.Text = String.Empty
    End Sub

    Private Sub BtnActReniec_Click(sender As System.Object, e As System.EventArgs) Handles BtnActReniec.Click
        '  Try
        CargarImagenReniec()
        AplicacionFiltros()
        LeerCaptchaReniec()
        Me.txtCapcha.SelectAll()
        Me.txtCapcha.Focus()
    End Sub

    Private Sub txttipo_dcto_TextChanged(sender As System.Object, e As System.EventArgs)
       

    End Sub

    Private Sub txttipo_dcto_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txttipo_dcto.SelectedIndexChanged
        If txttipo_dcto.Text = "RUC" Then
            CargarImagen()
            LeerCaptchaSunat()
            Me.txtCapcha.SelectAll()
            Me.txtCapcha.Focus()
        ElseIf txttipo_dcto.Text = "DNI" Then
            CargarImagenReniec()
            AplicacionFiltros()
            LeerCaptchaReniec()
            Me.txtCapcha.SelectAll()

            Me.txtCapcha.Focus()
        End If
    End Sub
End Class
