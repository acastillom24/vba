﻿Imports VB = Microsoft.VisualBasic

Public Class FrmDNI
    Dim IE As Object
    Dim nombre, consulta, ubicacion As Object
    Dim rta1, rta2 As String
    Dim dni As String


    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Cursor = Cursors.WaitCursor
        consultax()
        Cursor = Cursors.Default
    End Sub

    Sub consultax()
        IE = CreateObject("InternetExplorer.Application")

        wait(1)
        IE.Navigate("http://www.votoinformado.pe/voto/miembro_mesa.aspx")
        wait(1)
        Do Until IE.ReadyState = WebBrowserReadyState.Complete
            Application.DoEvents()
        Loop

        wait(1)
        IE.Document.all.Item("txtCongrDNI").value = TextBox1.Text
        wait(1)

        consulta = IE.document.getElementbyId("btnCongrDNI")
        wait(1)
        consulta.click()
        wait(1)
        Do Until IE.ReadyState = WebBrowserReadyState.Complete
            Application.DoEvents()
        Loop

        wait(1)
        nombre = IE.Document.getElementbyId("lblNombres")
        TextBox2.Text = DirectCast(nombre, mshtml.HTMLSpanElementClass).IHTMLElement_innerText
        wait(1)
        ubicacion = IE.Document.getElementbyId("lblUbicacion")
        TextBox3.Text = DirectCast(ubicacion, mshtml.HTMLSpanElementClass).IHTMLElement_innerText

    End Sub

    Public Sub wait(ByVal seconds As Single)
        Static start As Single
        start = VB.Timer()
        Do While VB.Timer() < start + seconds
            System.Windows.Forms.Application.DoEvents()

        Loop
    End Sub
End Class