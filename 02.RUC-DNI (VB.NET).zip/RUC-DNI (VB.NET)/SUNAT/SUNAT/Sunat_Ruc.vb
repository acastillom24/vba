﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Drawing
Imports System.Net
Imports System.IO
Imports System.Web
Imports System.Text.RegularExpressions

'Imports HtmlAgilityPack

Public Class Sunat_Ruc
    Public Enum Resul
        Ok = 0
        NoResul = 1
        ErrorCapcha = 2
        [Error] = 3
    End Enum
    Private state As Resul
    Private _Nombres As String
    Private _RUC As String
    Private _ApePaterno As String
    Private _Direccion As String
    ' Private _Direcion As String
    Private _Telefono As String
    Private _TipoEmpresa As String
    Private _RazonSocial As String
    'Private _CondiContribuyente As String
    'Private _InicioActi As String
    'Private _FIncripcion As String
    'Private _EmiComprobante As String
    ' Private _SisContabilidad As String
    ' Private _ComerExterior As String
    ' Private _ActiEconomica As String
    'Private _Oficio As String
    Private myCookie As CookieContainer

   
    Public ReadOnly Property GetCapcha As Image
        Get
            Return ReadCapcha()
        End Get
    End Property
    Public ReadOnly Property Nombres As String
        Get
            Return _Nombres
        End Get
    End Property
    Public ReadOnly Property ApePaterno As String
        Get
            Return _ApePaterno
        End Get
    End Property
    'Public ReadOnly Property Direcion() As String
    '    Get
    '        Return _Direcion
    '    End Get
    'End Property
    Public ReadOnly Property Direccion As String
        Get
            Return _Direccion
        End Get
    End Property
    'Public ReadOnly Property Estado As String
    '    Get
    '        Return _Estado
    '    End Get
    'End Property
    Public ReadOnly Property Telefono As String
        Get
            Return _Telefono
        End Get
    End Property
    Public ReadOnly Property RazonSocial As String
        Get
            Return _RazonSocial
        End Get
    End Property
    Public ReadOnly Property RUC As String
        Get
            Return _RUC
        End Get
    End Property
    Public ReadOnly Property TipoEmpresa As String
        Get
            Return _TipoEmpresa
        End Get
    End Property
    'Public ReadOnly Property NomComercial As String
    '    Get
    '        Return _NomComercial
    '    End Get
    'End Property
    'Public ReadOnly Property CondiContribuyente As String
    '    Get
    '        Return _CondiContribuyente
    '    End Get
    'End Property
    'Public ReadOnly Property FInscripcion As String
    '    Get
    '        Return _FIncripcion
    '    End Get
    'End Property
    'Public ReadOnly Property InicioActiviades As String
    '    Get
    '        Return _InicioActi
    '    End Get
    'End Property
    'Public ReadOnly Property EmiComprobante As String
    '    Get
    '        Return _EmiComprobante
    '    End Get
    'End Property

    'Public ReadOnly Property SisContabilidad As String
    '    Get
    '        Return _SisContabilidad
    '    End Get
    'End Property
    'Public ReadOnly Property ComerExterior As String
    '    Get
    '        Return _ComerExterior
    '    End Get
    'End Property
    'Public ReadOnly Property ActiEconomica As String
    '    Get
    '        Return _ActiEconomica
    '    End Get
    'End Property

    'Public ReadOnly Property Oficio As String
    '    Get
    '        Return _Oficio
    '    End Get
    'End Property

    Public ReadOnly Property GetResul As Resul
        Get
            Return state
        End Get

    End Property
    Public Sub New()
        Try
            myCookie = Nothing
            myCookie = New CookieContainer()
            ServicePointManager.Expect100Continue = True
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3
            ReadCapcha()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Function ValidarCertificado(sender As Object, certificate As System.Security.Cryptography.X509Certificates.X509Certificate, chain As System.Security.Cryptography.X509Certificates.X509Chain, sslPolicyErrors As System.Net.Security.SslPolicyErrors) As [Boolean]
        Return True
    End Function
    Private Function ReadCapcha() As Image
        Try
            System.Net.ServicePointManager.ServerCertificateValidationCallback = New System.Net.Security.RemoteCertificateValidationCallback(AddressOf ValidarCertificado)
            Dim myWebRequest As HttpWebRequest = DirectCast(WebRequest.Create("http://www.sunat.gob.pe/cl-ti-itmrconsruc/captcha?accion=image&magic=2"), HttpWebRequest)
            myWebRequest.CookieContainer = myCookie
            myWebRequest.Proxy = Nothing
            myWebRequest.Credentials = CredentialCache.DefaultCredentials
            Dim myWebResponse As HttpWebResponse = DirectCast(myWebRequest.GetResponse(), HttpWebResponse)
            Dim myImgStream As Stream = myWebResponse.GetResponseStream()
            Return Image.FromStream(myImgStream)
        Catch ex As Exception
            Throw ex

        End Try

    End Function

    Public Sub GetInfo(numDni As String, ImgCapcha As String)
        Dim xRazSoc As String = ""
        Dim xEst As String = ""
        Dim xCon As String = ""
        Dim xDir As String = ""
        Dim xAg As String = ""
        Dim xTel As String = ""
        Dim xTipoEmpre As String = ""
        Dim xNomComercial As String = ""
        Dim xFInscripcion As String = ""
        Dim xIniActiviades As String = ""
        Dim xCondiContribuyente As String = ""
        Dim xEmiComprobante As String = ""
        Dim xSisContabilidad As String = ""
        Dim xComerExterior As String = ""
        Dim xActiEconomica As String = ""
        Dim xOficio As String = ""
        Try
            'A este link le pasamos los datos , RUC y valor del captcha
            Dim myUrl As String = [String].Format("http://www.sunat.gob.pe/cl-ti-itmrconsruc/jcrS00Alias?accion=consPorRuc&nroRuc={0}&codigo={1}", numDni, ImgCapcha)
            Dim myWebRequest As HttpWebRequest = DirectCast(WebRequest.Create(myUrl), HttpWebRequest)
            myWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0"
            myWebRequest.CookieContainer = myCookie
            myWebRequest.Credentials = CredentialCache.DefaultCredentials
            myWebRequest.Proxy = Nothing

            Dim myHttpWebResponse As HttpWebResponse = DirectCast(myWebRequest.GetResponse(), HttpWebResponse)
            Dim myStream As Stream = myHttpWebResponse.GetResponseStream()
            Dim myStreamReader As New StreamReader(myStream)
            'Leemos los datos
            Dim xDat As String = WebUtility.HtmlDecode(myStreamReader.ReadToEnd())

            Dim _split As String() = xDat.Split(New Char() {"<"c, ">"c, ControlChars.Lf, ControlChars.Cr})
            Dim _resul As New List(Of String)()
            For i As Integer = 0 To _split.Length - 1
                If Not String.IsNullOrEmpty(_split(i).Trim()) Then
                    _resul.Add(_split(i).Trim())
                End If
            Next
            Select Case _resul.Count
                Case 77
                    state = Resul.ErrorCapcha
                    Exit Select
                Case Is >= 635
                    state = Resul.Ok
                    Exit Select
                Case 147
                    state = Resul.NoResul
                    Exit Select
                Case Else
                    state = Resul.[Error]
                    Exit Select
            End Select

            If state = Resul.Ok Then
                Dim tabla() As String
                xDat = Replace(xDat, "     ", " ")
                xDat = Replace(xDat, "     ", " ")
                xDat = Replace(xDat, "     ", " ")
                xDat = Replace(xDat, "    ", " ")
                xDat = Replace(xDat, "    ", " ")
                xDat = Replace(xDat, "    ", " ")
                xDat = Replace(xDat, "   ", " ")
                xDat = Replace(xDat, "   ", " ")
                xDat = Replace(xDat, "   ", " ")
                xDat = Replace(xDat, "  ", " ")
                xDat = Replace(xDat, "  ", " ")
                xDat = Replace(xDat, "  ", " ")
                xDat = Replace(xDat, "( ", "(")
                xDat = Replace(xDat, "( ", "(")
                xDat = Replace(xDat, "( ", "(")
                xDat = Replace(xDat, " )", ")")
                xDat = Replace(xDat, " )", ")")
                xDat = Replace(xDat, " )", ")")

                'Lo convertimos a tabla o mejor dicho a un arreglo de string como se ve declarado arriba
                tabla = Regex.Split(xDat, "<td class")
                If numDni.StartsWith("1") Then
                    'hacemos el parseo
                    tabla(1) = tabla(1).Replace("=""bg"" colspan=3>" & numDni & " - ", "")
                    tabla(1) = tabla(1).Replace("</td>" & vbCrLf & " </tr>" & vbCrLf & " <tr>" & vbCrLf & "", "")
                    'TIPO EMPRESA

                    tabla(3) = tabla(3).Replace("=""bg"" colspan=3>", "")
                    tabla(3) = tabla(3).Replace("</td>" & vbCr & vbLf & " </tr>" & vbCr & vbLf & " " & vbCr & vbLf & " <tr>" & vbCr & vbLf & " ", "")

                    ''NOMBRE COMERCIAL
                    'tabla(7) = tabla(7).Replace("=""bg"" colspan=1>", "")
                    'tabla(7) = tabla(7).Replace("</td>" & vbCr & vbLf & " </tr>" & vbCr & vbLf & " " & vbCr & vbLf & " <tr>" & vbCr & vbLf & " ", "")
                    ''FECHA DE INSCRIPCION
                    'tabla(9) = tabla(9).Replace("=""bg"" colspan=1>", "")
                    'tabla(9) = tabla(9).Replace("</td>" & vbCrLf & "   </tr>" & vbCrLf & "   <tr>" & vbCrLf & "", "")
                    ''INICIO DE ACTIVIDADES
                    'tabla(10) = tabla(10).Replace("=""bg"" colspan=1>", "")
                    'tabla(10) = tabla(10).Replace("</td>" & vbCrLf & " </tr>" & vbCrLf & " <tr>" & vbCrLf & "", "")
                    ''ESTADO CONTRIBUYENTE
                    'tabla(12) = tabla(12).Replace("=""bg"" colspan=1>", "")
                    'tabla(12) = tabla(12).Replace("</td>", "")
                    ''CONDICION DE CONTRIBUYENTE
                    'tabla(15) = tabla(15).Replace("=""bg"" colspan=3>", "")
                    'tabla(15) = tabla(15).Replace("</td>" & vbCrLf & "  </tr>" & vbCrLf & "  <tr>" & vbCrLf & "", "")
                    'DIRECION
                    tabla(17) = tabla(17).Replace("=""bg"" colspan=3>", "")
                    tabla(17) = tabla(17).Replace("</td>" & vbCrLf & " </tr>" & vbCrLf & "<!-- SE COMENTO POR INDICACION DEL PASE PAS20134EA20000207 -->" & vbCrLf & "<!-- <tr> -->" & vbCrLf & "<!-- ", "")
                    'TELEFONO
                    tabla(19) = tabla(19).Replace("=""bg"" colspan=1>", "")
                    tabla(19) = tabla(19).Replace("</td> -->" & vbCrLf & "<!-- ", "")
                    ''EMISION DE COMPROBANTE
                    'tabla(23) = tabla(23).Replace("=""bg"" colspan=1>", "")
                    'tabla(23) = tabla(23).Replace("</td>", "")
                    ''COMERCIO EXTERIOR
                    'tabla(25) = tabla(25).Replace("=""bg"" colspan=1>", "")
                    'tabla(25) = tabla(25).Replace("</td>" & vbCrLf & "  </tr>" & vbCrLf & "  <tr>" & vbCrLf & "", "")
                    ''SISTEMA DE CONTABILIDAD
                    'tabla(27) = tabla(27).Replace("=""bg"" colspan=1>", "")
                    'tabla(27) = tabla(27).Replace("</td>", "")

                    ''OFICIO
                    'tabla(29) = tabla(29).Replace("=""bg"" colspan=1>", "")
                    'tabla(29) = tabla(29).Replace("</td> -->" & vbCrLf & "<!-- ", "")

                    '         <td class="bgn" colspan=1>Profesi&oacute;n u Oficio:</td>
                    '<td class="bg" colspan=1>INGENIERO</td>



                    ''ACTIVIDAD ECONOMICA
                    'tabla(31) = tabla(31).Replace("<select name=select>", "")
                    'tabla(31) = tabla(31).Replace("</td>", "")

                    xRazSoc = Trim(CStr(tabla(1)))
                    xTipoEmpre = Trim(CStr(tabla(3)))
                    ' xNomComercial = Trim(CStr(tabla(7)))
                    'xFInscripcion = Trim(CStr(tabla(9)))
                    'xIniActiviades = Trim(CStr(tabla(10)))
                    'xEst = Trim(CStr(tabla(12)))
                    'xCondiContribuyente = Trim(CStr(tabla(15)))
                    xDir = CStr(tabla(17))
                    xTel = Trim(CStr(tabla(19)))
                    'xComerExterior = Trim(CStr(tabla(25)))
                    'xEmiComprobante = Trim(CStr(tabla(23)))
                    'xSisContabilidad = Trim(CStr(tabla(27)))
                    'xOficio = Trim(CStr(tabla(29)))
                    'xActiEconomica = Trim(CStr(tabla(31)))

                ElseIf numDni.StartsWith("2") Then
                    'PARA EMPRESA
                    tabla(1) = tabla(1).Replace("=""bg"" colspan=3>" & numDni & " - ", "")
                    tabla(1) = tabla(1).Replace("</td>" & vbCrLf & " </tr>" & vbCrLf & " <tr>" & vbCrLf & "", "")
                    'TIPO EMPRESA
                    'tabla(3) = tabla(3).Replace("=""bg"" colspan=3>", "")
                    'tabla(3) = tabla(3).Replace("</td>" & vbCrLf & " </tr>" & vbCrLf & " <tr>" & vbCrLf & "", "")
                    tabla(3) = tabla(3).Replace("=""bg"" colspan=3>", "")
                    tabla(3) = tabla(3).Replace("</td>" & vbCr & vbLf & " </tr>" & vbCr & vbLf & " " & vbCr & vbLf & " <tr>" & vbCr & vbLf & " ", "")
                    ''NOMBRE COMERCIAL
                    'tabla(5) = tabla(5).Replace("=""bg"" colspan=1>", "")
                    'tabla(5) = tabla(5).Replace("</td>" & vbCr & vbLf & " </tr>" & vbCr & vbLf & " " & vbCr & vbLf & " <tr>" & vbCr & vbLf & " ", "")
                    ''FECHA DE INSCRIPCION
                    'tabla(7) = tabla(7).Replace("=""bg"" colspan=1>", "")
                    'tabla(7) = tabla(7).Replace("</td>" & vbCrLf & " </tr>" & vbCrLf & " <tr>" & vbCrLf & "", "")
                    ''tabla(7) = tabla(7).Replace("</td>" & vbCrLf & " </tr>" & vbCrLf & " <tr>" & vbCrLf & "", "")
                    ''INICIO DE ACTIVIDADES
                    'tabla(8) = tabla(8).Replace("=""bg"" colspan=1>", "")
                    'tabla(8) = tabla(8).Replace("</td>" & vbCrLf & " </tr>" & vbCrLf & " <tr>" & vbCrLf & "", "")
                    ''CONDICION DE CONTRIBUYENTE
                    'tabla(13) = tabla(13).Replace("=""bg"" colspan=3>", "")
                    'tabla(13) = tabla(13).Replace("</td>" & vbCrLf & "  </tr>" & vbCrLf & "  <tr>" & vbCrLf & "", "")
                    ''ESTADO CONTRIBUYENTE
                    'tabla(10) = tabla(10).Replace("=""bg"" colspan=1>", "")
                    'tabla(10) = tabla(10).Replace("</td>" & vbCrLf & "  </tr>" & vbCrLf & "  <tr>" & vbCrLf & "", "")
                    ''tabla(10) = tabla(10).Replace("</td>", "")
                    'DIRECCION
                    tabla(15) = tabla(15).Replace("=""bg"" colspan=3>", "")
                    tabla(15) = tabla(15).Replace("</td>" & vbCrLf & " </tr>" & vbCrLf & "<!-- SE COMENTO POR INDICACION DEL PASE PAS20134EA20000207 -->" & vbCrLf & "<!-- <tr> -->" & vbCrLf & "<!-- ", "")
                    'TELEFONO
                    tabla(17) = tabla(17).Replace("=""bg"" colspan=1>", "")
                    tabla(17) = tabla(17).Replace("</td> -->" & vbCrLf & "<!-- ", "")
                    ''SISTEMA DE CONTABILIDAD
                    'tabla(21) = tabla(21).Replace("=""bg"" colspan=1>", "")
                    'tabla(21) = tabla(21).Replace("</td>", "")
                    ''COMERCIO EXTERIOR
                    'tabla(23) = tabla(23).Replace("=""bg"" colspan=1>", "")
                    'tabla(23) = tabla(23).Replace("</td>" & vbCrLf & "  </tr>" & vbCrLf & "  <tr>" & vbCrLf & "", "")
                    ''EMISION DE COMPROBANTE
                    'tabla(25) = tabla(25).Replace("=""bg"" colspan=1>", "")
                    'tabla(25) = tabla(25).Replace("</td>", "")
                    ''ACTIVIDAD ECONOMICA
                    'tabla(27) = tabla(27).Replace("<select name=select>", "")
                    'tabla(27) = tabla(27).Replace("</td>", "")

                    xRazSoc = Trim(CStr(tabla(1)))
                    xTipoEmpre = Trim(CStr(tabla(3)))
                    'xNomComercial = Trim(CStr(tabla(5)))
                    'xFInscripcion = Trim(CStr(tabla(7)))
                    'xIniActiviades = Trim(CStr(tabla(8)))
                    'xEst = Trim(CStr(tabla(10)))
                    'xCondiContribuyente = Trim(CStr(tabla(13)))
                    xDir = CStr(tabla(15))
                    xTel = Trim(CStr(tabla(17)))
                    'xSisContabilidad = Trim(CStr(tabla(21)))
                    'xComerExterior = Trim(CStr(tabla(23)))
                    'xEmiComprobante = Trim(CStr(tabla(25)))
                    'xActiEconomica = Trim(CStr(tabla(27)))

                End If
                'los resultados
                'Como ven en el arreglo se pueden obtener mas datos pero yaa pues el parseo lo hacen uds...
                _Nombres = xRazSoc
                _Direccion = xDir
                '_Estado = xEst
                _Telefono = xTel
                '_InicioActi = xIniActiviades
                '_FIncripcion = xFInscripcion
                _TipoEmpresa = xTipoEmpre
                '_NomComercial = xNomComercial
                '_CondiContribuyente = xCondiContribuyente
                '_EmiComprobante = xEmiComprobante
                '_SisContabilidad = xSisContabilidad
                '_ComerExterior = xComerExterior
                '_ActiEconomica = xActiEconomica

            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

End Class
